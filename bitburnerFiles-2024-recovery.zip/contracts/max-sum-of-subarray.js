a = [-8,7,4,2,-3,9,3,0,7,1,10,4,-5,-3,8,1,-6,3,-6,7];

maxSum = Number.MIN_VALUE;

for (var i = 0; i < a.length; i++){
  currSum = 0;
  j = i;
  while (j < a.length) {
    currSum += a[j]
    if (currSum > maxSum) {
      maxSum = currSum;
    }
    j++;
  } 
}