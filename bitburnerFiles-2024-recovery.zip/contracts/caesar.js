//left shift caesar all caps

function rotateString(str, n){
  s = str.split("");
  shiftedOff = s.splice(0, n);
  rotated = s.concat(shiftedOff);
  return rotated.join("");
}

input = ["VIRUS LOGIN TABLE MEDIA FRAME", 12];
encoded = input[0];
offset = input[1];

alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

rotated = rotateString(alpha, offset);

decoded = [];

for(var i = 0; i < encoded.length; i++){
  character = encoded[i];
  if(character === " ") {
    decoded.push(" ");
  }
  else {
    decoded.push(alpha[ rotated.indexOf(character) ]);    
    //decoded.push(rotated[ alpha.indexOf(character) ]);    
  }
}

decoded.join("");