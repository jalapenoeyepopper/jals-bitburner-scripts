/** @param {NS} ns */
export async function main(ns) {
/*
11556 7698 4905 3003 1716 924  462  210  84   28   7    1

3858  2793 1902 1287 792  462  252  126  56   21   6    1

1065  801  615  495  330  210  126  70   35   15   5    1

264   186  120  165  120  84   56   35   20   10   4    1

78    66   55   45   36   28   21   15   10   6    3    1

12    11   10   9    8    7    6    5    4    3    2    1

1     1    1    1    1    1    1    1    1    1    1    1
*/


rows=7;
cols=12;

var grid = [];
for(var r = 0; r < rows; r++){
  grid.push(new Array(cols));
  grid[r][cols-1] = 1;
}
for(var li = 0; li < 12; li++){
  grid[rows-1][li] = 1;
}

for(var r = rows-2; r >= 0; r--){
  for(var c = cols-2; c >= 0; c--){
    grid[r][c] = grid[r+1][c] + grid[r][c+1];
  }
} 


}