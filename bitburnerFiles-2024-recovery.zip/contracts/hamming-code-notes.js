/** @param {NS} ns */
export async function main(ns) {

//ostensibly for contract-532264-Sector12 on server zer0
//realistically because this was a lot of work to fail, boohiss

/*
01100000
00000000
00000000
00000000
11011011
01011010
11111010
10010001
*/

var encoded = "0110000000000000000000000000000011011011010110101111101010010001";
var enArr = encoded.split("");
var parity1 = [3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63];
var parity2 = [3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31, 34, 35, 38, 39, 42, 43, 46, 47, 50, 51, 54, 55, 58, 59, 62, 63];
var parity4 = [5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31, 36, 37, 38, 39, 44, 45, 46, 47, 52, 53, 54, 55, 60, 61, 62, 63];
var parity8 = [9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31, 40, 41, 42, 43, 44, 45, 46, 47, 56, 57, 58, 59, 60, 61, 62, 63];
var parity16 = [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63];

var p1sum = 0;
var p2sum = 0;
var p4sum = 0;
var p8sum = 0;
var p16sum = 0;

for(var i = 0; i<31; i++) {
    p1sum += parseInt(enArr[ parity1[i] ]);
    p2sum += parseInt(enArr[ parity2[i] ]);
    p4sum += parseInt(enArr[ parity4[i] ]);
    p8sum += parseInt(enArr[ parity8[i] ]);
    p16sum += parseInt(enArr[ parity16[i] ]);
}
ns.tprint("Parity 1 bit is " + enArr[1] + " for sum: " + p1sum);
ns.tprint("Parity 2 bit is " + enArr[2] + " for sum: " + p2sum);
ns.tprint("Parity 4 bit is " + enArr[4] + " for sum: " + p4sum);
ns.tprint("Parity 8 bit is " + enArr[8] + " for sum: " + p8sum);
ns.tprint("Parity 16 bit is " + enArr[16] + " for sum: " + p16sum);

//TODO FIND BAD POSITION???
var badBit = parseInt(enArr[56]);
console.log("ERROR IN POSITION 56 bad bit: " + badBit);
enArr[56] = (badBit + 1) %2;
console.log("Fixed Bad Bit to " + enArr[56]);

//splice out parity bits
enArr.splice(16, 1);
enArr.splice(8, 1);
enArr.splice(4, 1);
enArr.splice(2, 1);
enArr.splice(1, 1);
enArr.splice(0, 1); //extended overall parity bit

var binaryMessage = enArr.join("");
ns.tprint("Binary Message: " + binaryMessage + " (length: " + binaryMessage.length + ")");

//TODO convert to decimal

}