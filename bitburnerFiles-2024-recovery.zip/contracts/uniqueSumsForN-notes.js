function uniqueSums(n) {
  if ( n === 2 ) { return 1; }
  if ( n === 3 ) { return 2; }

  var nPairs = Math.floor( n / 2 );
  var lastPairPartner = nPairs;
  if ( n % 2 === 1 ) { lastPairPartner++; }

  var nSubPairs = 0;
  for (var i = n-2; i > lastPairPartner; i--) {
    nSubPairs += Math.floor( i / 2 );
  }

  return nPairs + nSubPairs + uniqueSums(n-1);
}

/*

2 (1)
1 + 1

3 (2)
1 + 2
1 plus the 1 total we found for 2

4 (4)
1 + 3
1 plus the 2 total we found for 3
2 + 2

5 (6)
1 + 4
1 plus the 4 total we found for 4
2 + 3

6 (11)
1 + 5
1 plus the 6 total we found for 5
2 + 4
2 plus the 2 pairs we found for 4
3 + 3

7 (16)
1 + 6
1 plus the 11 total we found for 6
2 + 5
2 plus the 2 pairs we found for 5
3 + 4

8 (25)
1 + 7
1 plus the 16 total we found for 7
2 + 6
2 plus the 3 pairs we found for 6
3 + 5
3 plus the 2 pairs we found for 5
4 + 4

9 (35)
1 + 8
1 plus the 25 total we found for 8
2 + 7
2 plus the 3 pairs we found for 7
3 + 6
3 plus the 3 pairs we found for 6
4 + 5

10 (50)
1 + 9
1 plus the 35 total we found for 9
2 + 8
2 plus the 4 pairs we found for 8
3 + 7
3 plus the 3 pairs we found for 7
4 + 6
4 plus the 3 pairs we found for 6
5 + 5


well shit, apparently uniqueSums(15) is not 176 (strictly greater) or 203 (greater or equal)

which means my whole algorithm is wrong :(
  
*/