/** @param {NS} ns */
export async function main(ns) {
  var count = 0;
  var grid = [
    [54, 29, 13, 4, 0],
    [25, 16, 9,  4, 1],
    [9,  7,  5,  3, 1],
    [2,  2,  2,  2, 1],
    [0,  0,  0,  1, 0],
  ];
  var originalGrid = [
    [null, null, null, null, 0],
    [null, null, null, null, null],
    [null, null, null, null, null],
    [null, null, null, null, null],
    [0,    0,    0,    null, 1],
  ];

  function recursivePaths(row, col) {
    if (originalGrid[row][col] == 0) { //obstacle. do not proceed.
      return 0;
    }
    if (col < originalGrid[row].length-1 && row < originalGrid.length-1) {
      return recursivePaths(row, col+1) + recursivePaths(row+1, col);
    }
    if (col < originalGrid[row].length-1) {
      return recursivePaths(row, col+1)
    }
    if (row < originalGrid.length-1) {
      return recursivePaths(row+1, col);
    }
    return originalGrid[row][col];
  }

  ns.tprint( recursivePaths(0,0));
}