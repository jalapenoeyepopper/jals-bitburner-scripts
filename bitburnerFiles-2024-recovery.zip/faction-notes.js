

/*
Notes about factions

  Shadows of Anarchy
    Successful infiltration

  The Syndicate
    Hack and travel to Aevum?

  Ishima
    Offers Field & Security Work

  Tian Di Hui
    New Tokyo?

  Bitrunners 
    backdoor run4theh111z

  Daedalus
    run fl1ght.exe

  Megacorp
    gain sufficient position with company

  CyberSec
    backdoor "CSEC"

  Sector-12
    home in sector 12 & have $15 mil
    Enemies: Chongqing, New Tokyo, Ishima, Volhaven

  Nitesec
    backdoor "avmnite-02h"

  NetBurners
    level 80 with a nice hacknet

  The Black Hand
    backdoor I.I.I.I

  Four Sigma
    gain sufficient favor with company
*/

