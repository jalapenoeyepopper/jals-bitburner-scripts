/** @param {NS} ns */
export async function main(ns) {

  /* 
    TODO/WISHLIST
    store the forecasts?
    move reporting to its own script?
    report should help understand if forecasts are accurate
    report should have sorting options
    report should include visualizations

  */

const nTicks = 5; //how many ticks to track
const sids = ns.stock.getSymbols();
const stockDataFile = "stocks/data.json";
var stockData = [];

if(ns.args[0] === "report") {
  var data = ns.read(stockDataFile);
  stockData = JSON.parse(data);
  ns.tprint(stockData.slice(0, 5));
  ns.exit();
}

ns.tprint("Caution: Be sure you killed any prior run of this script.");

for(var i = 0; i < sids.length; i++) {
  var sid = sids[i];
  stockData.push({
    sid: sid,
    org: ns.stock.getOrganization(sid),
    volatility: ns.stock.getVolatility(sid),
    forecast: null,
    currentPrice: null,
    priceTrack: new Array(nTicks),
    castTrack: new Array(nTicks)
  });
}

stockData.sort(function(a, b) {
    return a.volatility - b.volatility;
});

ns.write(stockDataFile, JSON.stringify(stockData, null, 2), "w");

while(true) {
  await ns.stock.nextUpdate();
  for(var i = 0; i < stockData.length; i++) {
    var sid = stockData[i].sid;
    var forecast = ns.stock.getForecast(sid);
    stockData[i].forecast = forecast;
    stockData[i].castTrack.splice(0, 1); //removes 1 forecast at index 0
    stockData[i].castTrack.push(price); //adds 1 forcast at ending index
    var price = ns.stock.getPrice(sid);
    stockData[i].currentPrice = price;
    stockData[i].priceTrack.splice(0, 1); //removes 1 price at index 0
    stockData[i].priceTrack.push(price); //adds 1 price at ending index
  }
  ns.write(stockDataFile, JSON.stringify(stockData, null, 2), "w");
}

}