/** @param {NS} ns */
export async function main(ns) {
/*
Return value format of getInfiltration() is....
{
  "location": {
    "city": "Volhaven",
    "name": "NWO"
  },
  "reward": {
    "tradeRep": 218301.06946716452,
    "sellCash": 3602617146.0592394,
    "SoARep": 6409.412931844889
  },
  "difficulty": 3,
  "maxClearanceLevel": 50,
  "startingSecurityLevel": 8.53
}
*/

  let locations = ns.infiltration.getPossibleLocations();
  let allInfo = [];

  //ns.tprint(JSON.stringify(locations, null, 2));

  for (let i=0; i<locations.length; i++) {
    let info = ns.infiltration.getInfiltration(locations[i].name);
    allInfo.push(info);
  }

  allInfo.sort(function(a, b){
    return a.reward.tradeRep - b.reward.tradeRep;
  });

  let printMe = "City, Difficulty, Name, Trade For Rep";
  for (let i=0; i<allInfo.length; i++) {
    let info = allInfo[i];
    printMe += "\n" + info.location.city
      + ",  " + info.difficulty 
      + ", " + info.location.name 
      + ", " + info.reward.tradeRep;
  }

  ns.tprint(printMe);
}