/** @param {NS} ns */
export async function main(ns) {
  const treeDataFile = "startup/network-tree.json";
  const flatDataFile = "startup/network-flat.json"
  let flat = {}; //global we'll fill as we walk the tree

  let tree = [
    {
      hostname: "home",
      parent: null,
      children: getSubtree("home", null)
    }
  ];

  //ns.write(treeDataFile, JSON.stringify(tree, null, 2), "w");
  ns.write(treeDataFile, printTree(tree[0].children, 2), "w");
  ns.write(flatDataFile, JSON.stringify(flat, null, 2), "w");
  ns.tprint("Finished building tree.");



  function getSubtree(host, parent) {

    let branches = ns.scan(host); //returns array of server names
    branches.shift(); //first element is always the parent

    if (host === "home") { 
      //home scan includes darkweb and pservs, which we don't want
      //luckily, the home trunks are always these same 7 servers
      branches = [
        "n00dles",
        "foodnstuff",
        "sigma-cosmetics",
        "joesguns",
        "hong-fang-tea",
        "harakiri-sushi",
        "iron-gym"
      ];
    }
    else {
      flat[host] = {
        parent: parent,
        // rooted: false,
        portsneeded: ns.getServerNumPortsRequired(host),
        // backdoored: false,
        hacklevelneeded: ns.getServerRequiredHackingLevel(host),
        maxCash: ns.getServerMaxMoney(host),
        children: branches.slice()
      };
    }

    for (let i=0; i<branches.length; i++) {
      let name = branches[i];
      branches[i] = {
        hostname: name,
        // rooted: false,
        // portsneeded: ns.getServerNumPortsRequired(name),
        // backdoored: false,
        // hacklevelneeded: ns.getServerRequiredHackingLevel(name),
        // maxCash: ns.getServerMaxMoney(name),
        children: getSubtree(name, host)
      }
    }
    return branches;
  }

  function printTree(subtree, indent) {
    let p = "\n";
    for (let i=0; i<subtree.length; i++) {
      for (let j=0; j< indent; j++) {
        p += " ";
      }
      p += "\"" + subtree[i].hostname + "\","
        + printTree(subtree[i].children, indent + 2);
    }
    return p;
  }
}