/*
TODO

  check on the gang situation
  check on the pservs
  solve contracts
  check out programming todos below

*/


/** @param {NS} ns */
export async function main(ns) {

  //todo improve hacking scripts with formulas API
  //todo troubleshoot GO -- next time it errors, check the go/log.txt file
  //todo improve my GO strategy
  //todo better automate startup tasks
  //todo analyze stock market (later, buy and sell for profit)
  //todo fix bugs in infiltration-play.js

//source file 4 grants some cool singularity stuff
  //ns.singularity.installBackdoor();

}