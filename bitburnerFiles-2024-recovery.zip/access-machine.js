/** @param {NS} ns */
export async function main(ns) {
  //must provide a target argument when running this program
  const accessTarget = ns.args[0];
  const hackScriptRAM = ns.getScriptRam("hack-rooted.js");

  //if possible, open the 5 ports
  if (ns.fileExists("BruteSSH.exe", "home")) {
    ns.brutessh(accessTarget);
  }
  if (ns.fileExists("FTPCrack.exe", "home" )) {
    ns.ftpcrack(accessTarget);
  }
  if (ns.fileExists("relaySMTP.exe", "home")) {
    ns.relaysmtp(accessTarget);
  }
  if (ns.fileExists("HTTPWorm.exe", "home")) {
    ns.httpworm(accessTarget);
  }
  if (ns.fileExists("SQLInject.exe", "home")) {
    ns.sqlinject(accessTarget);
  }

  // Get root access to target server
  ns.nuke(accessTarget);

  //copy the hacking script onto rooted server
  ns.scp("hack-rooted.js", accessTarget, "home");

  var freeRAM = 
    ns.getServerMaxRam(accessTarget) - 
    ns.getServerUsedRam(accessTarget);
  var threads = Math.floor(freeRAM/hackScriptRAM);

  var hackSkillNeeded = ns.getServerRequiredHackingLevel(accessTarget);
  var currentHackSkill = ns.getHackingLevel()

  //report
  ns.tprint("NUKE Successful. Connect to " + accessTarget);

  if(currentHackSkill < hackSkillNeeded) {
    ns.tprint("Raise your hack level to at least " + hackSkillNeeded + " to add backdoor.");
  }
  else {
    ns.tprint("backdoor available");
  }

  if(threads < 1) {
    ns.tprint("not enough free RAM to run hack-rooted.js");
  }
}