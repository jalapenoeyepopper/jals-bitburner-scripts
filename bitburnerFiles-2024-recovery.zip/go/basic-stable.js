/** @param {NS} ns */
export async function main(ns) {

  let result;
  let games = 0;
  let moveCounter = 0;

  const boardSize = 9;

  while(true) {
    await ns.sleep(100);

    if (result?.type === "gameOver") {
      ns.go.resetBoardState("Netburners", boardSize);
      moveCounter = 0;
      games++;
      if (games % 25 == 0) {
        ns.tprint("Played " + games + " games. Check stats.");
        //break; //nah don't break. just kill the script whenever.
      }
    }

    if (result?.type === "pass") {
      // just pass to end the game
      await ns.go.passTurn();
    }

    //prepare to select a move
    const board = ns.go.getBoardState();
    const validMoves = ns.go.analysis.getValidMoves();
    let myMove = []; 
    let x, y;

    //try to start on the diagonal
    if (moveCounter < 4) {
      myMove = getThirdLineMove(board, validMoves);
    } 

    //if no better move, choose a random one
    if (myMove[0] === undefined) {
      myMove = getRandomMove(board, validMoves);
    }    
    
    //make the move if possible
    x = myMove[0];
    y = myMove[1];
    if (x === undefined) {
      // Pass turn if no moves were found
      result = await ns.go.passTurn();
    } else {
      // Play the selected move
      result = await ns.go.makeMove(x, y);
      moveCounter++;
    }

  }

}

function getRandomMove(board, validMoves) {
  const moveOptions = [];
  const boardSize = board[0].length;

  // Look through all the points on the board
  for (let x = 0; x < boardSize; x++) {
    for (let y = 0; y < boardSize; y++) {
      const isNotReservedSpace = x % 2 === 1 || y % 2 === 1;
      // Make sure the point is a valid move
      if (validMoves[x][y] === true && isNotReservedSpace) {
        moveOptions.push([x, y]);
      }
    }
  }

  // Choose one of the found moves at random
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];

}

function getEarlyDiagonalMove(board, validMoves) {
  const moveOptions = [];
  const boardSize = board[0].length;

  //look through the diagonals, but not the corners
  const edgeRange = Math.round(boardSize / 4);
  for (let x = edgeRange; x < boardSize - edgeRange; x++) { 
    let y = x;
    let isValidMove = validMoves[x][y] === true;
    moveOptions.push([x, y]);

    y = boardSize - 1 - x; //the other diagonal
    isValidMove = validMoves[x][y] === true;
    moveOptions.push([x, y]);
  }

  // Choose one of the found moves at random
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];
}

function getThirdLineMove(board, validMoves) {
  const moveOptions = [];
  const boardSize = board[0].length;

  for (let x = 2; x < boardSize - 3; x++) {
    let y = 2;
    if (validMoves[x][y] === true) {
      moveOptions.push([x, y]);
    }
    y = boardSize - 3;
    if (validMoves[x][y] === true) {
      moveOptions.push([x, y]);
    }
  }
  // Choose one of the found moves at random
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];
}