/** @param {NS} ns */
export async function main(ns) {

  let result = {type: "gameOver"};
  let games = 0;
  let moveCounter = 0;
  let validMoves = ns.go.analysis.getValidMoves();
  let board = ns.go.getBoardState();

  const boardSize = 9;
  const opponent = "Netburners";

  const logDataFile = "go/log.txt";
  ns.write(logDataFile, "Starting the go/play.js script...", "w");

  //const liberties = ns.go.analysis.getLiberties();

  while(true) {
    await ns.sleep(1000);

    ns.write(logDataFile, "\n"+JSON.stringify(ns.go.getGameState()), "a");

    if (result?.type === "gameOver" || ns.go.getGameState().currentPlayer === "None") {
      ns.go.resetBoardState(opponent, boardSize);
      moveCounter = 0;
      games++;
      if (games % 25 == 0) {
        ns.tprint("Played " + games + " games. Check stats.");
      }
    }

    if (result?.type === "pass") {
      //just pass to end the game
      await ns.go.passTurn().catch(
        (err)=>ns.tprint('Go Passing failed again. Check the log.')
      );
    }
    //prepare to select a move
    let myMove = [];
    validMoves = ns.go.analysis.getValidMoves();
    board = ns.go.getBoardState();

    //early-game put out a few third-line stones
    if (moveCounter < 3) {
      myMove = getThirdLineMove();
    } 
    
    //if no better move, try main move algorithm
    if (myMove[0] === undefined) {
      myMove = getMove();
    }    
    
    //make the move if possible
    if (myMove[0] === undefined) {
      // Pass turn if no moves were found
      result = await ns.go.passTurn();
    } else {
      // Play the selected move
      result = await ns.go.makeMove(myMove[0], myMove[1]);
      moveCounter++;
    }

  }

  function getMove() {
    const moveOptions = [];
    const decentMoves = [];

    // Look through all the points on the board
    for (let x = 0; x < boardSize; x++) {
      for (let y = 0; y < boardSize; y++) {
        let validMove = validMoves[x][y] === true;
        let isNotReservedSpace = x % 2 === 1 || y % 2 === 1;

        //find out if it's a decent move
        if (validMove && isDecentMove(x, y) ) {
          decentMoves.push([x, y]);
        }
        //not a decent move? see if it's valid with gaps
        else if (validMove && isNotReservedSpace) {
          moveOptions.push([x, y]);
        }
      }
    }

    if (decentMoves.length > 0) {
      const randIdx = Math.floor(Math.random() * decentMoves.length);
      return decentMoves[randIdx];
    }
    // else choose one of the valid moves at random
    const randomIndex = Math.floor(Math.random() * moveOptions.length);
    return moveOptions[randomIndex] ?? [];

  }

  function isDecentMove(x, y) {
    const nearbyNodes = [
      [x-1, y-1],
      [x-1, y],
      [x-1, y+1],
      [x,   y-1],
      [x,   y+1],
      [x+1, y-1],
      [x+1, y],
      [x+1, y+1]
    ];

    let nearbyOpen = 0; //how many open nodes are near
    let nearbyBlack = 0; //how many black pieces are near
    //let libTotal = 0; //sum of nearbyBlack liberty scores //TODO HOW TO USE THIS?

    for (let i = 0; i < nearbyNodes.length; i++) {
      let nodeLoc = nearbyNodes[i];
      if (nodeLoc.x >= 0 && nodeLoc.x < boardSize && 
          nodeLoc.y >= 0 && nodeLoc.y < boardSize
      ) {
        if (board[nodeLoc.x][nodeLoc.y] === ".") {
          nearbyOpen++;
        }
        else if (board[nodeLoc.x][nodeLoc.y] === "X") {
          nearbyBlack++;
          //libTotal += liberties[nodeLoc.x][nodeLoc.y];
        }
      }
    }

    return (nearbyBlack > 0 && nearbyOpen > 0); // && libTotal > 0
  }

  function getThirdLineMove() {
    const moveOptions = [];

    for (let x = 2; x < boardSize - 3; x++) {
      let y = 2;
      if (validMoves[x][y] === true) {
        moveOptions.push([x, y]);
      }
      y = boardSize - 3;
      if (validMoves[x][y] === true) {
        moveOptions.push([x, y]);
      }
    }
    // Choose one of the found moves at random
    const randomIndex = Math.floor(Math.random() * moveOptions.length);
    return moveOptions[randomIndex] ?? [];
  }



}