/** @param {NS} ns */
export async function main(ns) {
  const hostnames = ns.getPurchasedServers();
  const maxn = ns.getPurchasedServerLimit();
  const maxRam = 1048576; //in bitnode 2 it's 524288

  if (ns.args[0] === "report") {
    reportAll();
  }
  else if (ns.args[0] === "report1") {
    report(maxn-1);
  }
  else if (hostnames.length > 0) {
    upgradeReport(true);
  }
  else {
    newServerReport(true);
  }


  function newServerReport(alsoBuyThem) {
    let cash = ns.getServerMoneyAvailable("home");
    let cost = 0;
    let ram = 0;
    for (ram = 8; ram < maxRam; ram *= 2) {
      let nextCost = ns.getPurchasedServerCost(ram) * maxn;
      if (nextCost > cash) {
        break;
      }
      cost = nextCost;
    }
    ram /= 2; //the for-loop went once too far
    ns.tprint("You can afford servers of " + ram + "gb for $" + cost);
    if (alsoBuyThem) {
      const pre = "pserv-";
      const hostnames = ns.getPurchasedServers();
      let i = hostnames.length; //iterator starts at next available index
      let n = ns.getPurchasedServerLimit();
      while (i < n) {
        let hostname = ns.purchaseServer(pre + i, ram);
        ns.scp("hack-rooted.js", hostname);
        ++i;
      }
      ns.tprint("Bought pservs with ram "+ram);
      if (ram < 1024) {
        ns.tprint("You may wish to use the 'early' version of pserv updates "
          +"in worker-bees, until you can upgrade to 1024gb.");
      }
    }
  }

  function report(idx) {
    let host = hostnames[idx];
    let currentRam = ns.getServerMaxRam(host);
    let maxRam = ns.getPurchasedServerMaxRam(host);

    ns.tprint("Host Name: " + host);
    ns.tprint("Current Ram: " + currentRam);
    ns.tprint("Max Ram: " + maxRam);
    
    if(currentRam < maxRam) {
      let upgradeRam = currentRam * 2;
      let cost = ns.getPurchasedServerUpgradeCost(host, upgradeRam);
      ns.tprint("Upgrade to " + upgradeRam + "gb for $" + cost);
      upgradeRam = currentRam * 4;
      cost = ns.getPurchasedServerUpgradeCost(host, upgradeRam);
      ns.tprint("Upgrade to " + (upgradeRam) + "gb for $" + cost);
    }
    
    ns.tprint("Running script(s):\n" + JSON.stringify(ns.ps(host)));
  }

  function reportAll() {
      
    if (hostnames.length > 0) {
      for (let i = 0; i < hostnames.length; i++) {
        report(i);
      }
      upgradeReport();
    }
    else {
      ns.tprint("No purchased servers to report.");
      newServerReport();
    }
  }

  function upgradeRam(gb) {
    for (var i = 0; i < hostnames.length; i++) {
      ns.upgradePurchasedServer(hostnames[i], gb);
    }
  }

  function upgradeReport(alsoBuyThem) {
    //analysis data
    let min = maxRam + 1;
    let max = 0;
    let balancingCost = 0;

    //list with current ram
    let currentRamText = "\n\nCurrent RAM\n";
    for (let i = 0; i < hostnames.length; i++) {
      let currentRam = ns.getServerMaxRam(hostnames[i]);
      if (min > currentRam) {
        min = currentRam;
      }
      if (max < currentRam) {
        max = currentRam;
      }
      currentRamText += hostnames[i] + " " + currentRam + "\n";
    }
    if (min === max) {
      currentRamText += "All servers have " + min + "gb.\n";

      let host = hostnames[0];
      let nextRam = min * 2;

      let cash = ns.getServerMoneyAvailable("home");
      let affordable;

      while (nextRam <= maxRam) {
        let cost = maxn * ns.getPurchasedServerUpgradeCost(host, nextRam);
        if (cost < cash) {
          affordable = nextRam;
        }
        currentRamText += "Upgrade all to " + nextRam + "gb for $" + cost + "\n";
        nextRam *= 2;
      } 
      if (alsoBuyThem && affordable > min) {
        for (let i = 0; i < hostnames.length; i++) {
          ns.upgradePurchasedServer(hostnames[i], affordable);
        }
        currentRamText += "\nBOUGHT the upgrade to " + affordable + "gb for all pservs.";
      }
    }
    else {
      for (let i = 0; i < hostnames.length; i++) {
        let host = hostnames[i];
        let currentRam = ns.getServerMaxRam(host);
        currentRamText += host;
        if (currentRam === max) {
          currentRamText += " is already at " + currentRam + "gb\n"
        }
        else {
          let hostcost = ns.getPurchasedServerUpgradeCost(host, max);
          balancingCost += hostcost;
          currentRamText += "can upgrade to " + max + " for " + hostcost + "\n";
        }
      }
      currentRamText += "Total cost to level RAM: $" + balancingCost;
    }

    let output = "PServ Limit: " + maxn + currentRamText;
    ns.tprint(output);
  }

}