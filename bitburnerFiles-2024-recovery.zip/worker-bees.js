/** @param {NS} ns */
export async function main(ns) {

const ramNeed = 2.4; //last known need of hack-rooted.js
let totalBeeCash = 0;

var bees = [
  "n00dles", 
    "nectar-net",
  "foodnstuff",
  "joesguns",
  "hong-fang-tea",
  "iron-gym",
 
  "sigma-cosmetics",
    "max-hardware",  
      "silver-helix",
        "johnson-ortho", 
        "the-hub",
          // "catalyst", //411
          //   "alpha-ent",
          //     "snap-fitness",
          // "I.I.I.I", //357
          //   "lexo-corp", 
          //     "galactic-cyber", 
          //       "omnia",
          //         "zeus-med",
          //           "taiyang-digital",
          //         "defcomm", //cont

  "harakiri-sushi", 
    "zer0", 
    "CSEC",
      "omega-net",
        //"netlink", //390
      "neo-net",
        // "computek", //359
        //   "summit-uni",
        //     "rho-construction",
        "avmnite-02h",  
          // "zb-institute", //745
          // "rothman-uni", //399
      "phantasy",
        "crush-fitness",
          // "syscore", //634, cont's in 400s
];

var beesToDo = [ 

  "n00dles", 
  "nectar-net",
  "foodnstuff",
  "joesguns",
  "hong-fang-tea",
  "iron-gym",

  "harakiri-sushi",
  "sigma-cosmetics",
  
  "max-hardware",
  "silver-helix",
  "johnson-ortho", 
  "the-hub",
  "catalyst",
  "alpha-ent",
  "snap-fitness",
  "I.I.I.I",
  "lexo-corp", 
  "galactic-cyber", 
  "omnia",
  "zeus-med",
  "taiyang-digital",
  "defcomm",

  "zer0",
  "CSEC",
  "omega-net",
  "netlink",
  "neo-net",
  "computek", 
  "summit-uni",
  "rho-construction",
  "avmnite-02h",  
  "zb-institute",
  "rothman-uni",
  "phantasy",
  "crush-fitness",
  "syscore",

  "millenium-fitness",
  "aevum-police", 
  "global-pharm",
  "aerocorp", 
  "deltaone",
  "unitalife", 
  "solaris", 
  "icarus", 
  "zb-def", 
  "titan-labs", 
  "infocomm",
  "run4theh111z", 
    
  "fulcrumtech",
  "vitalife",
  "microdyne", 
  "stormtech",
  "4sigma", 
  "powerhouse-fitness",
  "ecorp",
  "megacorp",
  "omnitek",
  "blade", 
  "b-and-a",
  "fulcrumassets",
  "univ-energy", 
  "nova-med",
  "applied-energetics",
  "helios",
  ".", 
  "kuai-gong",
  
  "nwo", 
  "clarkinc",
  "The-Cave",
  "w0r1d_d43m0n" //????? hackskill

];

function accessBees(){
  for (var i = 0; i < beesToDo.length; i++) {
    var host = beesToDo[i];
    ns.exec("access-machine.js", "home", 1, host);
  }
}

function printContracts() {
  for (var i = 0; i < bees.length; i++) {
    var host = bees[i];
    ns.tprint("----- " + host + " -----");
    ns.tprint(ns.ls(host, "contract"));
  }
}

function getSortedBeeCash(includeZeros) {
  var beeCash = [];
  totalBeeCash = 0; //global from line 2-ish
  for (var i=0; i < bees.length; i++){
    var bcash = ns.getServerMaxMoney(bees[i]);
    var bee = {
      host: bees[i],
      cash: bcash
    };
    beeCash.push(bee);
    totalBeeCash += bcash;
  }
  beeCash.sort(function(a,b){ return b.cash - a.cash; }); //sort by cash desc
  if (includeZeros) {
    return beeCash;
  }
  while (beeCash[beeCash.length-1].cash === 0) {
    beeCash.pop();
  }
  return beeCash;
}

function printBeeCashDeetz(n) {
  n = n || 5;
  var sortedBeeCash = getSortedBeeCash(true);
  for (var i = 0; i < n; i++) { 
    var target = sortedBeeCash[i].host;
    ns.tprint("----------\n" + target + ": "
      + "\n\tMax Money: " + ns.getServerMaxMoney(target) 
      + "\n\tMoney Now: " + ns.getServerMoneyAvailable(target) 
      + "\n\tMin Security: " + ns.getServerMinSecurityLevel(target) 
      + "\n\tSecurity Now: " + ns.getServerSecurityLevel(target));
  }
}

function earlyPservHacks() {
  //use for ram < 1024
  var sortedBeeCash = getSortedBeeCash();
  const hostnames = ns.getPurchasedServers();
  const ramAvailable = ns.getServerMaxRam(hostnames[0]); 
  const threads = Math.floor(ramAvailable / ramNeed);
  var beeIdx = 0;
  for (var i = 0; i < hostnames.length; i++) { 
    var hackTarget = sortedBeeCash[beeIdx].host;
    beeIdx = (beeIdx + 1) % sortedBeeCash.length;
    ns.killall(hostnames[i]);
    ns.exec("hack-rooted.js", hostnames[i], threads, hackTarget);
  }
}

function updatePservHacks() {
  var sortedBeeCash = getSortedBeeCash();
  
  //prepare purchased servers
  const hostnames = ns.getPurchasedServers();
  const ramAvailable = ns.getServerMaxRam(hostnames[0]); //assumes all same

  //prepare threadcounts
  const threads = Math.floor(ramAvailable / ramNeed);
  const threadsPerTarget = Math.floor(threads/sortedBeeCash.length);
  const spareThreads = threads % sortedBeeCash.length;
  var spareThreadsTargetIdx = 0;

  //update the hack scripts
  for (var i = 0; i < hostnames.length; i++) { 
    ns.killall(hostnames[i]);
    for (var b = 0; b < sortedBeeCash.length; b++) {
      var hackTarget = sortedBeeCash[b].host;
      ns.exec("hack-rooted.js", hostnames[i], threadsPerTarget, hackTarget);
    }
    if (spareThreads > 0) {
      var hackTarget = sortedBeeCash[spareThreadsTargetIdx].host;
      ns.exec("hack-rooted.js", hostnames[i], threadsPerTarget, hackTarget);
      spareThreadsTargetIdx = (spareThreadsTargetIdx + 1) % sortedBeeCash.length;
    }
  }

  ns.tprint("Updated Pserv Hacks.");
}

function updateExternalHacks(early){ 
  var sortedBeeCash = getSortedBeeCash();
  var maxBeeTargets = Math.floor(bees.length/3);
  if (sortedBeeCash.length > maxBeeTargets) {
    sortedBeeCash = sortedBeeCash.slice(0, maxBeeTargets);
  }

  if (early) {
    //overwrite sortedBeeCash for first attempt at a bitnode
    sortedBeeCash = [
      {host: "n00dles"},
      {host: "sigma-cosmetics"},
      {host: "joesguns"}
    ]
  }

  //loop through all bees to set hacking scripts
  for (var i = 0; i < bees.length; i++) {
    //set up host
    var beeHost = bees[i];
    var ramAvailable = ns.getServerMaxRam(beeHost);
    var threads = Math.floor(ramAvailable / ramNeed);
    if (threads < 1) {
      continue; //not enough ram to hack a target
    }
    
    //set up target
    var hackTargetIdx = i % sortedBeeCash.length;
    var hackTarget = sortedBeeCash[hackTargetIdx].host;

    //update hack scripts for host to attack target
    ns.killall(beeHost);
    ns.exec("hack-rooted.js", beeHost, threads, hackTarget);
  }

  ns.tprint("Updated External Hacks.");

}

function updateHomeHacks(){
  var hackTargets = getSortedBeeCash();

  var ramAvailable = ns.getServerMaxRam("home");
  ramAvailable -= 75; //reserve some for other scripts
  var allThreads = Math.floor(ramAvailable / ramNeed);

  ns.killall();

  for (var i = 0; i < hackTargets.length; i++) {
    var threads = Math.floor(allThreads * (hackTargets[i].cash / totalBeeCash));
    if (threads > 0) {
      ns.exec("hack-rooted.js", "home", threads, hackTargets[i].host);
    }
  }

  ns.tprint("Restarted Hack Scripts Only on Home. Restart others as needed.");  
}

function earlyHomeHacks(){
  var hackTargets = [{host: "foodnstuff"}]; 

  var ramAvailable = ns.getServerMaxRam("home");
  ramAvailable -= 20; //reserve some for other scripts
  var threads = Math.floor(ramAvailable / ramNeed);
  var threadsPerHost = Math.floor(threads / hackTargets.length);

  ns.killall();

  for (var i = 0; i < hackTargets.length; i++) {
    ns.exec("hack-rooted.js", "home", threadsPerHost, hackTargets[i].host);
  }

  ns.tprint("Restarted Hack Scripts Only on Home. Restart others as needed.");  
}

// accessBees();
// updateExternalHacks();
// updatePservHacks();
// updateHomeHacks();

//printContracts();
//printBeeCashDeetz(5);

//earlyPservHacks(); 
//earlyHomeHacks();
//updateExternalHacks(true);
}