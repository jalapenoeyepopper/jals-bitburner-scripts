/** @param {NS} ns */
export async function main(ns) {
  let equips = ns.gang.getEquipmentNames();
  let totalRespect = ns.gang.getGangInformation().respect;

  if (ns.args[0]) { 
    let mem = ns.args[0];
    ns.gang.ascendMember(mem);
    for (var j=0; j<equips.length; j++) {
      ns.gang.purchaseEquipment(mem, equips[j]);
    }
    ns.tprint("Ascended and re-equipped only member "+mem);
  }

  else {
    let members = ns.gang.getMemberNames();
    let jobList = [
      "Ethical Hacking",
      "Territory Warfare",
      "Cyberterrorism",
      "Money Laundering",
      "Cyberterrorism",
      "Money Laundering",
      "Cyberterrorism",
      "Money Laundering",
      "Cyberterrorism",
      "Cyberterrorism",
      "Cyberterrorism",
      "Cyberterrorism"
    ];
    shuffle(jobList);

    let output = "";
    
    for (var i = 0; i < members.length; i++) {
      await ns.sleep(10000);
      let member = members[i];
      
      if (ns.gang.getAscensionResult(member).respect > 0.2 * totalRespect) {
        output += "\nDid NOT ascend " + member;
        continue;
      }

      ns.gang.setMemberTask(member, jobList[i]);
      ns.gang.ascendMember(member);
      for (var j = 0; j < equips.length; j++) {
        let equip = equips[j];
        ns.gang.purchaseEquipment(member, equip);
      }
      output += "\nAscended and re-equipped " + member;
    }

    ns.tprint("Ascended, re-equipped, and re-assigned all members with "
      +"respect < 20% of gang total." + output);
  }

}

function shuffle(array) {
  let currentIndex = array.length;

  // While there remain elements to shuffle...
  while (currentIndex != 0) {

    // Pick a remaining element...
    let randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }
}