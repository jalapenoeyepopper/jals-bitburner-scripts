/** @param {NS} ns */
export async function main(ns) {
  let gangFactionName = ns.args[0] || "Slum Snakes";
  let gangKarma = -54000;
  let karma = ns.getPlayer().karma;
  //let karma = ns.heart.break();


  while (true) {
    await ns.sleep(10000);

    if (karma < gangKarma && ns.gang.createGang(gangFactionName)){
      ns.tprint("Created Gang with " + gangFactionName);
      break;
    }
    let output = "Could not create gang.\n"
      + "You currently have " + karma + " karma.\n"
      + "You need " + gangKarma + " to create a gang.";
    ns.tprint(output);
  }
}