/** @param {NS} ns */
export async function main(ns) {
  const prefix = "auto-";
  let members = ns.gang.getMemberNames();

  let lastMember, nextNumber;

  if (members.length === 0) {
    nextNumber = 1;
  }
  else {
    lastMember = members[members.length-1].split("-");
    nextNumber = parseInt(lastMember[1]) + 1;
  }
  

  while( true ) {
    await ns.sleep(5000);
    if( ns.gang.canRecruitMember() ) {
      let name = prefix + nextNumber;
      nextNumber++;

      ns.gang.recruitMember(name)
      ns.tprint("Recruited a new Gang Member: " + name);
      
      ns.gang.setMemberTask(name, "Territory Warfare");
    }
  }
}