/** @param {NS} ns */
export async function main(ns) {
  let wut = ns.gang.getAscensionResult(ns.gang.getMemberNames()[0]);
  let wut2 = ns.gang.getGangInformation();
  let wut3 = ns.gang.getOtherGangInformation();
  ns.tprint(wut);
  ns.tprint(wut2);
  ns.tprint(wut3);

  // ns.tprint(ns.gang.getGangInformation());
  // while( true ) {
  //   await ns.sleep(5000);
  //   if( ns.gang.canRecruitMember() ) {
  //     ns.tprint("Recruit a Gang Member!");
  //   }
  // }

  
}